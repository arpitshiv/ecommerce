package com.example.Customer.Service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Customer.Service.Repository.CustomerRepository;
import com.example.Customer.Service.entity.Customer;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    public Customer registerCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    public Customer validateCustomer(String username, String password) {
        Customer customer = customerRepository.findById(username).orElse(null);
        if (customer != null && customer.getPassword().equals(password)) {
            return customer;
        }
        return null;
    }
}