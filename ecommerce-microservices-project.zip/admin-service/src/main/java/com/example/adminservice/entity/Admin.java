package com.example.adminservice.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Admin {
    @Id
    private String username;
    private String password;

    // Getters and Setters
}
