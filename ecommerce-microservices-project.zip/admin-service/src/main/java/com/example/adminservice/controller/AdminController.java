package com.example.adminservice.controller;

import com.example.adminservice.entity.Admin;
import com.example.adminservice.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AdminController {
    @Autowired
    private AdminService adminService;

    @PostMapping("/admin/login")
    public String login(String username, String password, Model model) {
        Admin admin = adminService.authenticate(username, password);
        if (admin != null) {
            return "redirect:/admin/products";
        } else {
            model.addAttribute("error", "Invalid credentials");
            return "admin/login";
        }
    }
}
