package com.example.adminservice.service;

import com.example.adminservice.entity.Admin;
import com.example.adminservice.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminService {
    @Autowired
    private AdminRepository adminRepository;

    public Admin authenticate(String username, String password) {
        return adminRepository.findByUsernameAndPassword(username, password);
    }
}
