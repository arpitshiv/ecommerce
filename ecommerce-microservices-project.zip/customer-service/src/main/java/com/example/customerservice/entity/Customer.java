package com.example.customerservice.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Customer {
    @Id
    private String email;
    private String password;

    // Getters and Setters
}
