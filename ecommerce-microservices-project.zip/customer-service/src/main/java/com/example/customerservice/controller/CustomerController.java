package com.example.customerservice.controller;

import com.example.customerservice.entity.Customer;
import com.example.customerservice.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping("/customer/login")
    public String login(String email, String password, Model model) {
        Customer customer = customerService.authenticate(email, password);
        if (customer != null) {
            return "redirect:/customer/products";
        } else {
            model.addAttribute("error", "Invalid credentials");
            return "customer/login";
        }
    }
}
