package com.example.Customer.Service.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Customer.Service.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, String> {
}