package com.example.Customer.Service.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.Customer.Service.entity.Customer;
import com.example.Customer.Service.service.CustomerService;

@Controller
@RequestMapping("/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("customer", new Customer());
        return "customer/register";
    }

    @PostMapping("/register")
    public String registerCustomer(@ModelAttribute Customer customer) {
       customerService.registerCustomer(customer);
        return "redirect:/customer/login";
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "customer/login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, Model model) {
        Customer customer = customerService.validateCustomer(username, password);
        if (customer != null) {
            model.addAttribute("customer", customer);
            return "redirect:/customer/products";
        }
        model.addAttribute("error", "Invalid credentials");
        return "customer/login";
    }
}

