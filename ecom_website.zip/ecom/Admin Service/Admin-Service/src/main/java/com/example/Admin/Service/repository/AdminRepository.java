package com.example.Admin.Service.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Admin.Service.entity.Admin;

public interface AdminRepository extends JpaRepository<Admin, String> {
    Admin findByUsernameAndPassword(String username, String password);
}
